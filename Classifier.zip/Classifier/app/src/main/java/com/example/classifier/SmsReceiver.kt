package com.example.classifier

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import android.widget.Toast

/**
 * Standalone SMS Receiver - registered in AndroidManifest as backup
 * This ensures SMS are received even when app is in background
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d("SmsReceiver", "SMS received in standalone receiver!")

        if (intent?.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)

            for (sms in messages) {
                val body = sms.displayMessageBody
                val sender = sms.displayOriginatingAddress

                Log.d("SmsReceiver", "SMS from $sender: $body")

                // Show a toast notification (you'll see this when app is closed)
                context?.let {
                    Toast.makeText(it, "SMS Detected! Open app to analyze.", Toast.LENGTH_SHORT).show()
                }

                // TODO: In future, you can start MainActivity or a service here
                // to analyze the SMS even when app is closed
            }
        }
    }
}